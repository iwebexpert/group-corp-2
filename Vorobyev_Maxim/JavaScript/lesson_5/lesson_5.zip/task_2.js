//task 2
var a = 2;
var x = 1 + (a *= 2); //5
console.log(x);
