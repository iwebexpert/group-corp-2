//task 5
function sum(a, b) {
  return a + b;
}

function difference(a, b) {
  return a - b;
}

function composition(a, b) {
  return a * b; 
}

function division(a, b) {
  if (b == 0) {
    return;
  } else {
    return a / b; 
  }
}
